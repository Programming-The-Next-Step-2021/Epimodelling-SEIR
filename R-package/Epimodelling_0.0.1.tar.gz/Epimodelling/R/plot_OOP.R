################################################################################################
#This is a plotting function for SEIR previously solved by the solve_SEIR
#Author: Bence Gergely
#Version: plot_SEIR_05_05
#Language: R
#Language version: 4.0.5
#Variables used:
###res = matrix of results from solve_SEIR
###main = main title of the graph
#Reference:
### https://en.wikipedia.org/wiki/Compartmental_models_in_epidemiology
### https://fabiandablander.com/r/Nonlinear-Infection.html

#' @export

plot.Epimodelled <- function(res, main = ""){
  
  vars <- colnames(res)
  vars <- vars[-(length(vars) : (length(vars) - 1)) ]

  time <- res[, ncol(res)]

  matplot(
    time, 
    res[, 1:(ncol(res) - 2)],
    type = 'l',
    axes = FALSE,
    lty = 1, lwd = 2,
    ylab = 'Population %', xlab = 'Days', ylim = c(0, 1), xlim = c(0, tail(time, 1)),
    main = main, cex.main = 1.75, cex.lab = 1.25, font.main = 1, 
    xaxs = 'i', yaxs = 'i'
  )

  axis(1, cex.axis = 1.5)
  axis(2, las = 2, cex.axis = 1.5)
  
  legend("topright",
         legend = vars, 
         lty = 1, lwd = 2,
         bty = 'n', cex = 1.5, 
         col = 1:length(vars)
  )


}


