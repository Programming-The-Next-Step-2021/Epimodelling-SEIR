library(testthat)
library(Epimodelling)

test_check("Epimodelling")
